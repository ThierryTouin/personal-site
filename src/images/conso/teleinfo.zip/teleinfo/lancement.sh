cd /home/pi/teleinfo
python3 teleinfo.py
