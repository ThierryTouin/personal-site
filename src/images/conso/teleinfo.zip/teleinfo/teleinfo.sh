#!/bin/sh

timeout 2 /usr/local/bin/snmp/cat /dev/ttyS0 1> /tmp/acm0

hchp=`cat /tmp/acm0 | grep HCHP | tail -n 1 | cut -f2 -d' '`
hchc=`cat /tmp/acm0 | grep HCHC | tail -n 1 | cut -f2 -d' '`
iinst=`cat /tmp/acm0 | grep IINST | tail -n 1 | cut -f2 -d' '`
imax=`cat /tmp/acm0 | grep IMAX | tail -n 1 | cut -f2 -d' '`
papp=`cat /tmp/acm0 | grep PAPP | tail -n 1 | cut -f2 -d' '`
ptec=`cat /tmp/acm0 | grep PTEC | tail -n 1 | cut -f2 -d' '`
if [ $ptec = "HP.." ]
then
 ptec=1
elif [ $ptec = "HC.." ]
then
 ptec=0
fi

printf "hchp:%1.0f hchc:%1.0f iinst:%1.0f imax:%1.0f papp:%1.0f ptec:%s\n" $hchp $hchc $iinst $imax $papp $ptec

exit 0

