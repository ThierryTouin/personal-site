## Lancement après reboot
Ce contenu permet un redémarrage du système tous les jours à 3h00 du matin suivi d'un lancement du serveur de teleinfo.

### Pour ouvrir la crontab en edition
`crontab -e`

### Y mettre le contenu suivant :

```
0 3 * * * root /usr/sbin/shutdown -r now
@reboot sleep 120 && sh /home/pi/teleinfo/lancement.sh > /home/pi/teleinfo/logs/log.txt 2>&1
```

