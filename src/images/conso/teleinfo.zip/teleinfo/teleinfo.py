#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Thierry TOUIN"
# __licence__ = "Apache License 2.0"

# Python 3, prerequis : pip install pySerial influxdb
#
# Exemple de trame:
# {
#  'OPTARIF': 'HC..',        # option tarifaire
#  'IMAX': '007',            # intensité max
#  'HCHC': '040177099',      # index heure creuse en Wh
#  'IINST': '005',           # Intensité instantanée en A
#  'PAPP': '01289',          # puissance Apparente, en VA
#  'MOTDETAT': '000000',     # Mot d'état du compteur
#  'HHPHC': 'A',             # Horaire Heures Pleines Heures Creuses
#  'ISOUSC': '45',           # Intensité souscrite en A
#  'ADCO': '000000000000',   # Adresse du compteur
#  'HCHP': '035972694',      # index heure pleine en Wh
#  'PTEC': 'HP..'            # Période tarifaire en cours
# }


import serial
import logging
import time
import requests
from datetime import datetime
#from influxdb import InfluxDBClient

# clés téléinfo
int_measure_keys = ['IMAX', 'HCHC', 'IINST', 'PAPP', 'ISOUSC', 'ADCO', 'HCHP']

# url jeedom
api_url = "https://<jeedom-domain>/core/api/jeeApi.php?plugin=virtual&type=event&apikey=<jeedom-key>&id="
api_url_token = "&value="
iinst_id = "358"
papp_id = "359"
hchc_id = "363"
hchp_id = "364"

# création du logguer
logging.basicConfig(filename='/home/pi/test/logs/releve.log', level=logging.INFO, format='%(asctime)s %(message)s')
logging.info("Teleinfo starting..")

timeDelay1 = 600
timeMark1 = time.time()
timeDelay2 = 3600
timeMark2 = time.time()


def add_measures1(measures):

    for measure, value in measures.items():
         #print(measure," = " , value)
         if measure == 'IINST' :
             url = api_url+iinst_id+api_url_token+str(value)
             #print(url)
             response = requests.get(url)
             #print("response:", response.json())
         if measure == 'PAPP' :
             url = api_url+papp_id+api_url_token+str(value)
             #print(url)
             response = requests.get(url)
             #print("response:", response.json())


def add_measures2(measures):

    for measure, value in measures.items():
         #print(measure," = " , value)
         if measure == 'HCHC' :
             url = api_url+hchc_id+api_url_token+str(value)
             #print(url)
             response = requests.get(url)
             #print("response:", response.json())
         if measure == 'HCHP' :
             url = api_url+hchp_id+api_url_token+str(value)
             #print(url)
             response = requests.get(url)
             #print("response:", response.json())


def add_measures_conditions1(measures, time_measure):

    global timeMark1
    global timeDelay1
    timeCurent = time.time()
    #print("timeCurent:",timeCurent)
    #print("timeMark1:",timeMark1)
    #print("timeDelay1:",timeDelay1)
    if (timeCurent-timeMark1 < timeDelay1):
        #print("wait before send resultat !") 
        return

    timeMark1 = timeCurent

    add_measures1(measures)

def add_measures_conditions2(measures, time_measure):

    global timeMark2
    global timeDelay2
    timeCurent = time.time()
    #print("timeCurent:",timeCurent)
    #print("timeMark2:",timeMark2)
    #print("timeDelay2:",timeDelay2)
    if (timeCurent-timeMark2 < timeDelay2):
        #print("wait before send resultat !") 
        return

    timeMark2 = timeCurent

    add_measures2(measures)


def main():
    with serial.Serial(port='/dev/ttyS0', baudrate=1200, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE,
                       bytesize=serial.SEVENBITS, timeout=1) as ser:

        logging.info("Teleinfo is reading on /dev/ttyS0..")

        trame = dict()

        # boucle pour partir sur un début de trame
        line = ser.readline()
        while b'\x02' not in line:  # recherche du caractère de début de trame
            line = ser.readline()

        # lecture de la première ligne de la première trame
        line = ser.readline()

        while True:
            line_str = line.decode("utf-8")
            ar = line_str.split(" ")
            try:
                key = ar[0]
                if key in int_measure_keys :
                    value = int(ar[1])
                else:
                    value = ar[1]

                checksum = ar[2]
                trame[key] = value
                if b'\x03' in line:  # si caractère de fin dans la ligne, on insère la trame dans influx
                    del trame['ADCO']  # adresse du compteur : confidentiel!
                    time_measure = time.time()

                    # insertion dans influxdb
                    add_measures_conditions1(trame, time_measure)
                    add_measures_conditions2(trame, time_measure)

                    # ajout timestamp pour debugger
                    trame["timestamp"] = int(time_measure)
                    logging.debug(trame)


                    trame = dict()  # on repart sur une nouvelle trame
            except Exception as e:
                logging.error("Exception : %s" % e)
            line = ser.readline()



if __name__ == '__main__':
#    if connected:
        main()

